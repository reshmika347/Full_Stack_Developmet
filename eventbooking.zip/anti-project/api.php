<?php
// PHP API for JSON Data Exchange
// File: api.php

// Include database connection
require_once 'db.php';

// Set headers for JSON response and CORS
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow local development
header('Access-Control-Allow-Methods: GET, POST'); 
header('Access-Control-Allow-Headers: Content-Type');

// Get the action from the request (e.g., ?action=get_shoes)
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Helper function to return JSON and exit
function sendResponse($status, $message, $data = null) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

try {
    switch ($action) {
        
        // 1. Fetch Dashboard Stats
        case 'get_dashboard_stats':
            // Example queries
            $stmt1 = $pdo->query("SELECT COUNT(*) as count FROM shoes");
            $totalShoes = $stmt1->fetchColumn();
            
            $stmt2 = $pdo->query("SELECT COUNT(*) as count FROM suppliers");
            $totalSuppliers = $stmt2->fetchColumn();
            
            $stmt3 = $pdo->query("SELECT COUNT(*) as count FROM shoes WHERE stock_quantity < 10");
            $lowStockItems = $stmt3->fetchColumn();
            
            $stmt4 = $pdo->query("SELECT COUNT(*) as count FROM shoes WHERE stock_quantity = 0");
            $outOfStockItems = $stmt4->fetchColumn();
            
            sendResponse('success', 'Stats fetched', [
                'total_shoes' => $totalShoes,
                'total_suppliers' => $totalSuppliers,
                'low_stock' => $lowStockItems,
                'out_of_stock' => $outOfStockItems
            ]);
            break;

        // 2. Fetch Recent Transactions
        case 'get_recent_transactions':
            $query = "
                SELECT t.id as transaction_id, s.name as product_name, t.type, t.quantity, t.transaction_date, t.order_id
                FROM transactions t
                JOIN shoes s ON t.shoe_id = s.id
                ORDER BY t.transaction_date DESC
                LIMIT 10
            ";
            $stmt = $pdo->query($query);
            $transactions = $stmt->fetchAll();
            sendResponse('success', 'Transactions fetched', $transactions);
            break;
            
        // 3. Add a new shoe product
        case 'add_shoe':
            // Only accept POST requests
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                sendResponse('error', 'Invalid request method');
            }
            
            // Read JSON input
            $input = json_decode(file_get_contents('php://input'), true);
            
            // Basic validation
            if (!isset($input['name']) || !isset($input['brand']) || !isset($input['price'])) {
                sendResponse('error', 'Missing required fields');
            }
            
            $stmt = $pdo->prepare("INSERT INTO shoes (name, brand, size, color, category_id, supplier_id, stock_quantity, price) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            
            $stmt->execute([
                $input['name'],
                $input['brand'],
                $input['size'] ?? 0,
                $input['color'] ?? '',
                $input['category_id'] ?? null,
                $input['supplier_id'] ?? null,
                $input['stock_quantity'] ?? 0,
                $input['price']
            ]);
            
            sendResponse('success', 'Shoe added successfully', ['id' => $pdo->lastInsertId()]);
            break;
            
        // 4. Update Stock (Stock In / Stock Out)
        case 'update_stock':
             if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                sendResponse('error', 'Invalid request method');
            }
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($input['shoe_id']) || !isset($input['type']) || !isset($input['quantity']) || !isset($input['user_id'])) {
                sendResponse('error', 'Missing required fields');
            }
            
             // Start a transaction to ensure both queries succeed
            $pdo->beginTransaction();
            
            // Log the transaction
            $stmt1 = $pdo->prepare("INSERT INTO transactions (shoe_id, user_id, type, quantity) VALUES (?, ?, ?, ?)");
            $stmt1->execute([$input['shoe_id'], $input['user_id'], $input['type'], $input['quantity']]);
            
            // Update the actual stock quantity in the shoes table
            $operator = ($input['type'] === 'stock_in') ? '+' : '-';
            $stmt2 = $pdo->prepare("UPDATE shoes SET stock_quantity = stock_quantity $operator ? WHERE id = ?");
            $stmt2->execute([$input['quantity'], $input['shoe_id']]);
            
            $pdo->commit();
            sendResponse('success', 'Stock updated successfully');
            break;

        default:
            sendResponse('error', 'Invalid or missing action parameter');
            break;
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    // Return JSON error response for debugging
    sendResponse('error', 'Server error: ' . $e->getMessage());
}
?>
